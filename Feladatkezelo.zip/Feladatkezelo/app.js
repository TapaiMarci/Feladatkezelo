import express from 'express';
import bcrypt from 'bcrypt';
import bodyParser from 'body-parser';
import db from './db.js';

const app = express();
app.use(bodyParser.json());
app.use(express.static('public')); 

let sessions = {};

app.post('/api/register', async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Hiányzó adat' });
    const hash = await bcrypt.hash(password, 10);
    try {
        db.prepare('INSERT INTO users (email, password_hash) VALUES (?,?)').run(email, hash);
        res.json({ message: 'Regisztráció sikeres' });
    } catch (e) {
        res.status(400).json({ error: 'Email már létezik' });
    }
});

app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
    if (!user) return res.status(400).json({ error: 'Hibás email' });
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) return res.status(400).json({ error: 'Hibás jelszó' });
    const token = Math.random().toString(36).substring(2);
    sessions[token] = user.id;
    res.json({ token });
});

function auth(req, res, next) {
    const token = req.headers['authorization'];
    if (!token || !sessions[token]) return res.status(401).json({ error: 'Nem bejelentkezett' });
    req.user_id = sessions[token];
    next();
}

app.get('/api/tasks', auth, (req, res) => {
    const tasks = db.prepare('SELECT * FROM tasks WHERE user_id=?').all(req.user_id);
    res.json(tasks);
});

app.post('/api/tasks', auth, (req, res) => {
    const { title, description, status, deadline } = req.body;
    const info = db.prepare('INSERT INTO tasks (user_id,title,description,status,deadline) VALUES (?,?,?,?,?)')
        .run(req.user_id, title, description, status||'pending', deadline);
    const task = db.prepare('SELECT * FROM tasks WHERE id=?').get(info.lastInsertRowid);
    res.json(task);
});

app.put('/api/tasks/:id', auth, (req, res) => {
    const { id } = req.params;
    const { title, description, status, deadline } = req.body;
    db.prepare('UPDATE tasks SET title=?, description=?, status=?, deadline=? WHERE id=? AND user_id=?')
      .run(title, description, status, deadline, id, req.user_id);
    const task = db.prepare('SELECT * FROM tasks WHERE id=?').get(id);
    res.json(task);
});

app.delete('/api/tasks/:id', auth, (req, res) => {
    const { id } = req.params;
    db.prepare('DELETE FROM tasks WHERE id=? AND user_id=?').run(id, req.user_id);
    res.json({ message: 'Task törölve' });
});

app.listen(3000, () => console.log('Server: http://localhost:3000'));